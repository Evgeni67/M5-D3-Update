const express = require("express");
const cors = require("cors");
const projectsRoutes = require("./services/projects");

const server = express();
const port = process.env.PORT || 3002;

server.use(cors());
server.use(express.json()); // I need to specify this line of code otherwise all the request bodies will be undefined. And this line of code must come BEFORE the routes
const loggerMiddleware = (req, res, next) => {
  console.log(`Logged ${req.url} ${req.method} -- ${new Date()}`);
  next();
};
server.use("/projects", projectsRoutes);
server.use(loggerMiddleware);
server.listen(port, () => {
  console.log("Server is running on port: ", port);
});
