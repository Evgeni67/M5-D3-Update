/*
1. get all projects on url --> localhost:3001/projects/
2. get single Projects on url --> localhost:3001/projects/:id
3. create a single Projects --> localhost:3001/projects
4. modify a single Projects --> localhost:3001/projects/:id
5. delete a single Projects --> localhost:3001/projects/:id
*/

const express = require("express");
const fs = require("fs");
const path = require("path");
const uniqid = require("uniqid");

const router = express.Router();

router.get("/", (req, res) => {
  const projectsFilePath = path.join(__dirname, "projects.json");
  const fileAsABuffer = fs.readFileSync(projectsFilePath);
  const fileAsAString = fileAsABuffer.toString();
  const projectsAsArray = JSON.parse(fileAsAString);
  res.send(projectsAsArray);
});

router.get("/:identifier", (req, res) => {
  const projectsFilePath = path.join(__dirname, "projects.json");
  const fileAsABuffer = fs.readFileSync(projectsFilePath);
  const fileAsAString = fileAsABuffer.toString();
  const projectsAsArray = JSON.parse(fileAsAString);
  const idFromParams = req.params.identifier;
  const projectt = projectsAsArray.filter(
    (project) => project.id === idFromParams
  );
  res.send(projectt);
});

router.post("/", (req, res) => {
  const projectsFilePath = path.join(__dirname, "projects.json");
  const fileAsABuffer = fs.readFileSync(projectsFilePath);
  const fileAsAString = fileAsABuffer.toString();
  const projectsAsArray = JSON.parse(fileAsAString);

  //get the new project from the request's body
  const newProject = req.body;
  newProject.id = uniqid();
  projectsAsArray.push(newProject);
  fs.writeFileSync(projectsFilePath, JSON.stringify(projectsAsArray));
  res.status(201).send(newProject);
});

router.put("/:id", (req, res) => {
  const projectsFilePath = path.join(__dirname, "projects.json");
  const fileAsABuffer = fs.readFileSync(projectsFilePath);
  const fileAsAString = fileAsABuffer.toString();
  const projectsAsArray = JSON.parse(fileAsAString);
  //find the index
  const index = projectsAsArray.findIndex((user) => user.ID === req.params.id);
  const modifiedUser = req.body;
  modifiedUser.id = req.params.id;
  projectsAsArray[index] = modifiedUser;
  fs.writeFileSync(projectsFilePath, JSON.stringify(projectsAsArray));
  res.send("User Modified Succesfully");
});

router.delete("/:id", (req, res) => {
  const projectsFilePath = path.join(__dirname, "projects.json");
  const fileAsABuffer = fs.readFileSync(projectsFilePath);
  const fileAsAString = fileAsABuffer.toString();
  const projectsAsArray = JSON.parse(fileAsAString);
  //filter it out
  const newprojectsArray = projectsAsArray.filter(
    (project) => project.id !== req.params.id
  );
  fs.writeFileSync(projectsFilePath, JSON.stringify(newprojectsArray));
  res.send(newprojectsArray);
});

module.exports = router;
